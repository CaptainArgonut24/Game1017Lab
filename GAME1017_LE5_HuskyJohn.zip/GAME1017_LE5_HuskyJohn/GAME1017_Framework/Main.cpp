/*******************************************************************************
* File Name   :
* Description :
* Author      :
* Created     :
* Modified    :
*******************************************************************************/

#include "Engine.h"

int main(int argc, char* argv[])
{
	return Engine::Instance().Run();
}
